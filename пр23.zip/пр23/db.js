const sqlite3 = require('sqlite3').verbose();

class Database {
  constructor() {
    this.db = null;
  }

  connect() {
    this.db = new sqlite3.Database('./auth.db', (err) => {
      if (err) {
        console.error('Ошибка подключения к БД:', err.message);
      } else {
        console.log('Подключение к SQLite установлено');
      }
    });
  }

  disconnect() {
    if (this.db) {
      this.db.close((err) => {
        if (err) {
          console.error('Ошибка закрытия БД:', err.message);
        } else {
          console.log('Подключение к SQLite закрыто');
        }
      });
    }
  }
}

module.exports = new Database();