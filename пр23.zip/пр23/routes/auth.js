const express = require('express');
const User = require('../models/User');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { email, password, role } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: 'Email и пароль обязательны' });
    }
    
    const user = await User.create({ email, password, role });
    const token = User.generateToken(user);
    
    res.status(201).json({
      message: 'Пользователь создан',
      token,
      user: { id: user.id, email: user.email, role: user.role }
    });
  } catch (error) {
    if (error.message.includes('UNIQUE constraint failed')) {
      res.status(400).json({ error: 'Пользователь с таким email уже существует' });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: 'Email и пароль обязательны' });
    }
    
    const user = await User.findByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Неверный email или пароль' });
    }
    
    const isValidPassword = await User.verifyPassword(password, user.password_hash);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Неверный email или пароль' });
    }
    
    const token = User.generateToken(user);
    
    res.json({
      message: 'Успешный вход',
      token,
      user: { id: user.id, email: user.email, role: user.role }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/profile', authenticateToken, (req, res) => {
  res.json({ 
    message: 'Профиль пользователя',
    user: req.user 
  });
});

router.get('/admin', authenticateToken, requireRole('admin'), (req, res) => {
  res.json({ 
    message: 'Админская панель',
    user: req.user 
  });
});

module.exports = router;