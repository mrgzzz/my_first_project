const db = require('./db');

db.connect();

const authors = [
  { name: 'Лев Толстой', birth_year: 1828 },
  { name: 'Федор Достоевский', birth_year: 1821 },
  { name: 'Антон Чехов', birth_year: 1860 }
];

const categories = [
  { name: 'Роман' },
  { name: 'Рассказ' },
  { name: 'Драма' }
];

const books = [
  { title: 'Война и мир', author_id: 1, category_id: 1, isbn: '978-5-389-00001-1', publication_year: 1869 },
  { title: 'Анна Каренина', author_id: 1, category_id: 1, isbn: '978-5-389-00002-8', publication_year: 1877 },
  { title: 'Преступление и наказание', author_id: 2, category_id: 1, isbn: '978-5-389-00003-5', publication_year: 1866 },
  { title: 'Вишневый сад', author_id: 3, category_id: 3, isbn: '978-5-389-00004-2', publication_year: 1904 }
];

authors.forEach(author => {
  db.db.run('INSERT INTO authors (name, birth_year) VALUES (?, ?)', 
    [author.name, author.birth_year]);
});

categories.forEach(category => {
  db.db.run('INSERT INTO categories (name) VALUES (?)', [category.name]);
});

setTimeout(() => {
  books.forEach(book => {
    db.db.run('INSERT INTO books (title, author_id, category_id, isbn, publication_year) VALUES (?, ?, ?, ?, ?)', 
      [book.title, book.author_id, book.category_id, book.isbn, book.publication_year]);
  });
  console.log('Тестовые данные добавлены');
}, 100);

setTimeout(() => db.disconnect(), 500);