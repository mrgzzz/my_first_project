const db = require('../db');

class Book {
  static findAll(page = 1, limit = 10) {
    return new Promise((resolve, reject) => {
      const offset = (page - 1) * limit;
      
      db.db.all(`
        SELECT books.*, authors.name as author_name, categories.name as category_name 
        FROM books 
        LEFT JOIN authors ON books.author_id = authors.id 
        LEFT JOIN categories ON books.category_id = categories.id 
        LIMIT ? OFFSET ?
      `, [limit, offset], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  static findById(id) {
    return new Promise((resolve, reject) => {
      db.db.get(`
        SELECT books.*, authors.name as author_name, categories.name as category_name 
        FROM books 
        LEFT JOIN authors ON books.author_id = authors.id 
        LEFT JOIN categories ON books.category_id = categories.id 
        WHERE books.id = ?
      `, [id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  static create(bookData) {
    return new Promise((resolve, reject) => {
      const { title, author_id, category_id, isbn, publication_year } = bookData;
      
      db.db.run(
        'INSERT INTO books (title, author_id, category_id, isbn, publication_year) VALUES (?, ?, ?, ?, ?)',
        [title, author_id, category_id, isbn, publication_year],
        function(err) {
          if (err) reject(err);
          else resolve({ id: this.lastID, ...bookData });
        }
      );
    });
  }

  static update(id, bookData) {
    return new Promise((resolve, reject) => {
      const fields = [];
      const values = [];
      
      Object.keys(bookData).forEach(key => {
        fields.push(`${key} = ?`);
        values.push(bookData[key]);
      });
      
      values.push(id);
      
      db.db.run(
        `UPDATE books SET ${fields.join(', ')} WHERE id = ?`,
        values,
        function(err) {
          if (err) reject(err);
          else resolve({ id, ...bookData });
        }
      );
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      db.db.run('DELETE FROM books WHERE id = ?', [id], function(err) {
        if (err) reject(err);
        else resolve({ deleted: this.changes });
      });
    });
  }
}

module.exports = Book;