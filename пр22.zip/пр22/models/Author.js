const db = require('../db');

class Author {
  static findAll() {
    return new Promise((resolve, reject) => {
      db.db.all('SELECT * FROM authors', (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  static findByIdWithBooks(id) {
    return new Promise((resolve, reject) => {
      db.db.get('SELECT * FROM authors WHERE id = ?', [id], (err, author) => {
        if (err) {
          reject(err);
          return;
        }
        
        if (!author) {
          resolve(null);
          return;
        }
        
        db.db.all(`
          SELECT books.*, categories.name as category_name 
          FROM books 
          LEFT JOIN categories ON books.category_id = categories.id 
          WHERE author_id = ?
        `, [id], (err, books) => {
          if (err) reject(err);
          else resolve({ ...author, books });
        });
      });
    });
  }

  static create(authorData) {
    return new Promise((resolve, reject) => {
      const { name, birth_year } = authorData;
      
      db.db.run(
        'INSERT INTO authors (name, birth_year) VALUES (?, ?)',
        [name, birth_year],
        function(err) {
          if (err) reject(err);
          else resolve({ id: this.lastID, ...authorData });
        }
      );
    });
  }
}

module.exports = Author;