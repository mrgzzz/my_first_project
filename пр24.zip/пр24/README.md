# Task Manager - Frontend + Backend Integration

## Backend Setup
```bash
cd backend
npm install
npm start