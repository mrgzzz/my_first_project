import React, { useState, useEffect } from 'react';
import ApiService from './api/service';
import ItemList from './components/ItemList';
import ItemForm from './components/ItemForm';
import './App.css';

function App() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    setLoading(true);
    setError('');
    try {
      const data = await ApiService.getItems();
      setItems(data);
    } catch (err) {
      setError('Failed to load items');
      console.error('Error loading items:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateItem = async (itemData) => {
    setError('');
    try {
      const newItem = await ApiService.createItem(itemData);
      setItems(prev => [...prev, newItem]);
    } catch (err) {
      setError('Failed to create item');
      throw err;
    }
  };

  const handleUpdateItem = async (id, itemData) => {
    setError('');
    try {
      const updatedItem = await ApiService.updateItem(id, itemData);
      setItems(prev => prev.map(item => 
        item.id === id ? updatedItem : item
      ));
    } catch (err) {
      setError('Failed to update item');
      throw err;
    }
  };

  const handleDeleteItem = async (id) => {
    setError('');
    try {
      await ApiService.deleteItem(id);
      setItems(prev => prev.filter(item => item.id !== id));
    } catch (err) {
      setError('Failed to delete item');
      throw err;
    }
  };

  return (
    <div className="app">
      <h1>Task Manager</h1>
      
      {error && <div className="error">{error}</div>}
      
      <ItemForm onSubmit={handleCreateItem} />
      
      {loading ? (
        <div className="loading">Loading...</div>
      ) : (
        <ItemList 
          items={items}
          onUpdate={handleUpdateItem}
          onDelete={handleDeleteItem}
        />
      )}
    </div>
  );
}

export default App;