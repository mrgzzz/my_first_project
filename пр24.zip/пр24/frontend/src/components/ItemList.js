import React, { useState } from 'react';

function ItemList({ items, onUpdate, onDelete }) {
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});

  const handleEdit = (item) => {
    setEditingId(item.id);
    setEditForm({ title: item.title, description: item.description });
  };

  const handleSave = async (id) => {
    try {
      await onUpdate(id, editForm);
      setEditingId(null);
      setEditForm({});
    } catch (error) {
    }
  };

  const handleCancel = () => {
    setEditingId(null);
    setEditForm({});
  };

  const handleToggleComplete = async (item) => {
    try {
      await onUpdate(item.id, { completed: !item.completed });
    } catch (error) {
    }
  };

  return (
    <div className="item-list">
      <h2>Items ({items.length})</h2>
      
      {items.length === 0 ? (
        <p>No items found</p>
      ) : (
        items.map(item => (
          <div key={item.id} className={`item ${item.completed ? 'completed' : ''}`}>
            {editingId === item.id ? (
              <div className="edit-form">
                <input
                  type="text"
                  value={editForm.title}
                  onChange={(e) => setEditForm(prev => ({ ...prev, title: e.target.value }))}
                />
                <input
                  type="text"
                  value={editForm.description}
                  onChange={(e) => setEditForm(prev => ({ ...prev, description: e.target.value }))}
                />
                <button onClick={() => handleSave(item.id)}>Save</button>
                <button onClick={handleCancel}>Cancel</button>
              </div>
            ) : (
              <>
                <div className="item-content">
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                  <span className="date">
                    Created: {new Date(item.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <div className="item-actions">
                  <button 
                    onClick={() => handleToggleComplete(item)}
                    className={item.completed ? 'completed' : ''}
                  >
                    {item.completed ? 'Completed' : 'Mark Complete'}
                  </button>
                  <button onClick={() => handleEdit(item)}>Edit</button>
                  <button onClick={() => onDelete(item.id)}>Delete</button>
                </div>
              </>
            )}
          </div>
        ))
      )}
    </div>
  );
}

export default ItemList;