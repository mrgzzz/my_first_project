import React, { useState } from 'react';

function ItemForm({ onSubmit }) {
  const [formData, setFormData] = useState({ title: '', description: '' });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.title.trim()) {
      alert('Title is required');
      return;
    }

    setSubmitting(true);
    try {
      await onSubmit(formData);
      setFormData({ title: '', description: '' });
    } catch (error) {
    } finally {
      setSubmitting(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="item-form">
      <h2>Add New Item</h2>
      
      <div className="form-group">
        <label>Title:</label>
        <input
          type="text"
          name="title"
          value={formData.title}
          onChange={handleChange}
          required
        />
      </div>
      
      <div className="form-group">
        <label>Description:</label>
        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
        />
      </div>
      
      <button type="submit" disabled={submitting}>
        {submitting ? 'Adding...' : 'Add Item'}
      </button>
    </form>
  );
}

export default ItemForm;